# Labelling brief: Library passages

Each line of your batch file is one passage from a public-domain novel. `templated_text` is the passage with its people, places, times, organisations and objects replaced by tokens: `{{PERSON_1}}`, `{{PLACE_1}}`, `{{TIME_1}}`, `{{ORG_1}}`, `{{OBJECT_1}}` and so on; `{{VARY_n}}` tokens are pronouns that follow the person cast. `slots` gives each token's published words (`surface`), and for most places a rough size (`place_size`). `published_text` is the original, for reading. `existing_labels` are earlier labels (people, story changes, main scene kind); use them as hints, not as truth.

## What the labels are for
NovelWriter lets a writer put a Library passage into their own chapter ("Insert Source Passage") and, later, builds scenes from passages. When a passage goes in, the app fills each blank with a value from the writer's own book: its places, its time of day, its people. Your labels tell the app:
- which value each place and time blank takes, and whether the passage puts its people **at** that place (so the app knows where people are afterwards);
- what the passage's fixed words commit the scene to (night, rain, winter, indoors), so the app never drops a moonlit passage into a morning scene;
- how each person feels by the end, where the passage says so;
- which organisation blanks are really a family or a person.

## Output
Write **one JSON line per passage**, in batch order, to `labels/batch_NN.labels.jsonl`:
```json
{"id": "...",
 "commits": {"time_of_day": ["night"], "season": [], "weather": ["rain"], "conveyance": [], "indoors": true},
 "people": [{"person": "{{PERSON_1}}", "feels_end": "anxious", "age": null}],
 "blanks": [{"token": "{{PLACE_1}}", "fill": "place.here", "located": true, "place_kind": "building", "form": "after_the", "allows": null},
            {"token": "{{TIME_1}}", "fill": "time_of_day", "located": false, "place_kind": null, "form": "that", "allows": null},
            {"token": "{{ORG_1}}", "fill": "keep", "located": false, "place_kind": null, "form": "name", "allows": null, "names": "family"}],
 "note": ""}
```

## Fields
**`commits`**: what the passage's **fixed** words (not its blanks) commit the scene to:
- `time_of_day`, `season`, `weather`, `conveyance`: lists of ids from `lists.json`, only where the words state it or make it certain ("the moon was up" is night; "the snow lay deep" is snow and winter; "the coach rattled on" is coach). Do not guess from mood.
- `indoors`: `true` (the people are inside a room or building), `false` (out of doors), or `null` when the passage does not say, or its people are inside a moving vehicle.

If a `keep` time blank's words read as one of these values ("to-night", "that winter"), that value must be in `commits` too.

**`people`**: one entry per PERSON token that is present in the scene (not one only mentioned):
- `feels_end`: the person's feeling by the passage's end, only where the passage states or plainly shows it, as an id from the `feeling` list; else `null`.
- `age`: whole years, only if the passage states it; else `null`.

**`blanks`**: one entry for **every PLACE, TIME and ORG token** in the passage (not PERSON, VARY or OBJECT).
- `fill`, for a place:
  - `place.here`: where the passage happens, or where its people are, when nobody moves between places;
  - `place.departed`: the place someone leaves, in a passage where someone goes from one place to another;
  - `place.reached`: the place someone reaches, in such a passage;
  - `keep`: the place must stay as published: a real place the story would not change ("London" in a passage about London's history), a place only mentioned in passing, a place in a name or title ("the Bishop of {{PLACE_1}}"), or a name that cannot be swapped without nonsense.
- `fill`, for a time: `time_of_day` (a time of day: "that evening", "at night"); `season` (a season word); `keep` for anything else (dates, holidays, durations, "to-morrow", years).
- `fill`, for an organisation: always `keep`.
- `located`: `true` only when the passage puts its people **at** that place (they are there, arrive there, or are there before leaving). `false` for a place only mentioned ("he had once lived in {{PLACE_1}}"), a destination not reached, a modifier ("the {{PLACE_1}} coach"), and every time and organisation blank. Be strict: this decides where the story thinks people are.
- `place_kind` (places only, else `null`): exactly one of `room`, `building`, `street`, `settlement`, `region`, `landscape`, `water`, `vessel`, from what the passage needs the place to be. `place_size` is a hint: `room_or_building` is room or building; `town_or_district` is street or settlement; `region_country_or_sea` is region or water.
- `form`:
  - places: `name` (stands as a name: "at {{PLACE_1}}"); `after_the` (the word "the" is right before the token in the text, outside it: "the {{PLACE_1}}"); `modifier` (before a noun, or as an adjective: "the {{PLACE_1}} road", "a {{PLACE_1}} man");
  - time of day and season: `bare` (evening), `the` (the evening), `that` (that evening), `in` (in the evening, at night, by day);
  - organisations, and `keep` times whose words fit none of these: `name`, `after_the` or `modifier` by the same rule as places.
- `allows`: optional list of ids that read naturally in this frame, when only some do. A place blank can list place kinds; a time blank time-of-day or season ids. `null` means any value of its kind.
- `names` (organisation blanks only): what the published words really name: `organisation` (a firm, regiment, church, club, ship's company, government body), `family` ("the Gardiners", "the Bennets"), `person` (one person), `place` (a place the earlier labeller took for an organisation), `other`.

**`note`**: anything a person should look at: a label you are unsure of, an earlier label that is clearly wrong, a blank that should not be a blank. Keep it short. Leave it empty otherwise.

## Rules
- Use only ids from `lists.json`. Never invent an id; put a suggestion in `note` instead.
- Never change `templated_text` or any slot.
- Read every passage in full. Label what the text does, not what the earlier labels say.
- Run `python check_labels.py NN` often (NN is your batch number). It checks ids, forms, coverage and the "the" rule. Finish only when it reports no errors and every passage labelled.
