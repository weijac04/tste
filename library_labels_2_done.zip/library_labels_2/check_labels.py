"""Check labelled batches: python check_labels.py [N ...]   (no argument = all ten)"""
import json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
L = json.load(open(os.path.join(HERE, "lists.json"), encoding="utf-8"))
TIME_WORDS = {"night": "time_of_day", "evening": "time_of_day", "morning": "time_of_day", "dawn": "time_of_day", "dusk": "time_of_day",
              "winter": "season", "summer": "season", "spring": "season", "autumn": "season"}
NAMES = ("organisation", "family", "person", "place", "other")
ALL_FORMS = set(L["forms"]["place"]) | set(L["forms"]["time_of_day"]) | set(L["forms"]["season"])

def has_the_before(text, t):
    i = text.find(t)
    m = re.search(r"(\S+)\s*$", text[:i]) if i >= 0 else None
    return bool(m and m.group(1).lower() == "the")

def check_batch(n):
    errs, warns = [], []
    src = [json.loads(l) for l in open(os.path.join(HERE, "passages", f"batch_{n:02d}.jsonl"), encoding="utf-8")]
    path = os.path.join(HERE, "labels", f"batch_{n:02d}.labels.jsonl")
    if not os.path.exists(path):
        return [f"{path} does not exist"], [], 0, len(src)
    labs = {}
    for i, line in enumerate(open(path, encoding="utf-8"), 1):
        if not line.strip(): continue
        try: r = json.loads(line)
        except Exception as ex: errs.append(f"line {i}: not JSON ({ex})"); continue
        if r.get("id") in labs: errs.append(f"{r.get('id')}: labelled twice")
        labs[r.get("id")] = r
    byid = {p["id"]: p for p in src}
    for pid in labs:
        if pid not in byid: errs.append(f"{pid}: not in this batch")
    for p in src:
        r = labs.get(p["id"])
        if r is None: continue
        e = lambda m: errs.append(f"{p['id']}: {m}")
        text = p["templated_text"]
        c = r.get("commits")
        if not isinstance(c, dict): e("commits missing"); c = {}
        for k in ("time_of_day", "season", "weather", "conveyance"):
            v = c.get(k, [])
            if not isinstance(v, list) or any(x not in L[k] for x in v): e(f"bad commits.{k}")
        if c.get("indoors", None) not in (True, False, None): e("bad commits.indoors")
        persons = {s["token"] for s in p["slots"] if s["type"] == "PERSON"}
        for pe in r.get("people", []):
            if pe.get("person") not in persons: e(f"people: {pe.get('person')} is not a PERSON token")
            if pe.get("feels_end") not in L["feeling"] + [None]: e(f"bad feels_end {pe.get('feels_end')}")
            if pe.get("age") is not None and not isinstance(pe.get("age"), int): e("age must be whole years or null")
        need = {s["token"]: s for s in p["slots"] if s["type"] in ("PLACE", "TIME", "ORG")}
        got = {}
        for b in r.get("blanks", []):
            t = b.get("token")
            if t not in need: e(f"blank {t}: not a PLACE/TIME/ORG token of this passage"); continue
            if t in got: e(f"blank {t}: labelled twice")
            got[t] = b
            typ = need[t]["type"]
            fill, form = b.get("fill"), b.get("form")
            if not isinstance(b.get("located"), bool): e(f"{t}: located must be true or false")
            the = has_the_before(text, t)
            if typ == "PLACE":
                if fill not in ("place.here", "place.departed", "place.reached", "keep"): e(f"{t}: a place takes place.here, place.departed, place.reached or keep")
                if b.get("place_kind") not in L["place_kind"]: e(f"{t}: needs one place_kind")
                if form not in ("name", "after_the", "modifier"): e(f"{t}: place form must be name, after_the or modifier")
                if the and form != "after_the": e(f"{t}: 'the' stands before it, so its form is after_the")
                if form == "after_the" and not the: e(f"{t}: form after_the but no 'the' before it")
                if b.get("allows") is not None and any(x not in L["place_kind"] for x in b["allows"]): e(f"{t}: bad allows")
                if fill == "keep" and b.get("located"): warns.append(f"{p['id']}: {t} is keep but located")
            elif typ == "TIME":
                if fill not in ("time_of_day", "season", "keep"): e(f"{t}: a time takes time_of_day, season or keep")
                if fill in ("time_of_day", "season") and form not in L["forms"][fill]: e(f"{t}: bad form for {fill}")
                if fill == "keep" and form not in ALL_FORMS: e(f"{t}: bad form")
                if b.get("located"): e(f"{t}: only a place can be located")
                if b.get("place_kind") is not None: e(f"{t}: place_kind must be null for a time")
                if fill in ("time_of_day", "season") and b.get("allows") is not None and any(x not in L[fill] for x in b["allows"]): e(f"{t}: bad allows")
                surf = (need[t].get("surface") or "").lower()
                if fill == "keep":
                    for w, k in TIME_WORDS.items():
                        if re.search(rf"\b{w}\b", surf) and not c.get(k): warns.append(f"{p['id']}: {t} keeps '{surf}' but commits.{k} is empty")
            else:
                if fill != "keep": e(f"{t}: an organisation blank is keep")
                if b.get("names") not in NAMES: e(f"{t}: names must be one of {NAMES}")
                if b.get("located"): e(f"{t}: only a place can be located")
                if form not in ("name", "after_the", "modifier"): e(f"{t}: form must be name, after_the or modifier")
                if the and form != "after_the": e(f"{t}: 'the' stands before it, so its form is after_the")
        for t in need:
            if t not in got: e(f"blank {t} not labelled")
    return errs, warns, len(labs), len(src)

if __name__ == "__main__":
    ns = [int(x) for x in sys.argv[1:]] or list(range(1, 11))
    bad = 0
    for n in ns:
        errs, warns, done, total = check_batch(n)
        print(f"batch {n:02d}: {done} of {total} labelled, {len(errs)} errors, {len(warns)} warnings")
        for x in errs[:80]: print("   ERROR", x)
        for x in warns[:30]: print("   warn ", x)
        bad += bool(errs) or done < total
    sys.exit(1 if bad else 0)
