# REVIEW: Library labels, part 2

## How the work was split

`PROMPT.md` called for 10 Sonnet subagents with one batch each. On Jack's instruction, this run used **5 Sonnet 5.5 subagents with two batches each**. Batches were paired so that each agent had a similar number of passages.

| Agent | Batches | Passages labelled |
|---|---|---|
| 1 | 01 + 10 | 168 + 117 = 285 |
| 2 | 02 + 09 | 129 + 140 = 269 |
| 3 | 03 + 08 | 162 + 147 = 309 |
| 4 | 04 + 07 | 151 + 140 = 291 |
| 5 | 05 + 06 | 195 + 123 = 318 |
| **Total** | | **1472 of 1472** |

Each agent received `BRIEF.md` verbatim, `lists.json`, its file names and its agent number.

- **Checker results:** all five agents finished with `check_labels.py` reporting every passage labelled, 0 errors and 0 warnings. No agent needed a return trip.
- **Checks after my fixes:** I re-ran `check_labels.py` on all ten batches; it still reports 0 errors and 0 warnings. A diff against the original zip confirms that no passage text, slots, `lists.json`, `BRIEF.md` or `check_labels.py` was changed.

## Counts (after my fixes)

### Place blanks: 675

| fill | count |
|---|---|
| `place.here` | 92 |
| `place.departed` | 9 |
| `place.reached` | 13 |
| `keep` | 561 |
| of all place blanks, `located: true` | 93 |

### Time blanks: 160

| fill | count |
|---|---|
| `time_of_day` | 13 |
| `season` | 2 |
| `keep` | 145 |

Most kept time blanks are dates, months, clock times, durations or "to-morrow".

### Organisation blanks: 88

| names | count |
|---|---|
| `organisation` | 64 |
| `family` | 12 |
| `person` | 0 |
| `place` | 1 |
| `other` | 11 |

### Place blanks per batch

| Batch | here | departed | reached | keep | located |
|---|---|---|---|---|---|
| 01 | 9 | 0 | 0 | 84 | 9 |
| 02 | 5 | 1 | 1 | 56 | 7 |
| 03 | 8 | 0 | 1 | 42 | 6 |
| 04 | 9 | 1 | 0 | 49 | 8 |
| 05 | 9 | 0 | 1 | 40 | 5 |
| 06 | 8 | 2 | 2 | 79 | 12 |
| 07 | 20 | 0 | 1 | 56 | 15 |
| 08 | 9 | 1 | 1 | 49 | 10 |
| 09 | 6 | 2 | 4 | 58 | 10 |
| 10 | 9 | 2 | 2 | 48 | 11 |

## Quality check

I read 25 passages per batch against their text, 250 in all. They were evenly spaced through each file, from the first passage to the last. I looked hardest at:

- `located`
- `fill` (especially departed and reached)
- `commits`
- `names` on organisation blanks
- forms of time blanks

A passage counts as an error below when it has a clear mistake. I did not count defensible judgement calls.

| Agent | Batches | Sampled | Clear errors | Sampled error rate |
|---|---|---|---|---|
| 1 | 01, 10 | 50 | 0 | 0% |
| 2 | 02, 09 | 50 | 1 | 2% |
| 3 | 03, 08 | 50 | 2 | 4% |
| 4 | 04, 07 | 50 | 1 | 2% |
| 5 | 05, 06 | 50 | 1 | 2% |
| **All** | | **250** | **5** | **2%** |

No agent's work was wrong throughout, so no batch needed a full re-pass. Outside the sample, I made two targeted sweeps across all ten batches:

1. **Narrator `located` sweep:** every place.here, departed or reached blank with `located: false`.
2. **Ship conveyance sweep:** shipboard passages with no conveyance.

## Fixes I made

### Errors found in the sample

| Batch | Passage | Token | What was wrong | Change |
|---|---|---|---|---|
| 02 | gutenqa-pg11012-the-autobiography-of-an-ex-colored-man-000015 | PLACE_1 (Georgia) | The narrator's remembered birthplace was marked as the scene and located. | `place.here`, located → `keep`, not located |
| 03 | P1_047 | TIME_1 ("that afternoon") | The form was `bare`, but the words carry "that". | form `bare` → `that`; allows `["day"]` |
| 06 | batch3-settings-pg169-000626-000627 | PLACE_1 (Plain of Abundance) | The person bides there and works among the haymakers, so the place is the scene. | `keep`, not located → `place.here`, located |
| 07 | P5-09-04 | commits | `conveyance: train` was set, but there is no train in the passage. | conveyance → `[]` |
| 08 | P5-09-05 | commits | `time_of_day: day` was set, but nothing in the text states the time. | time_of_day → `[]` |

### Narrator sweep (first-person passages)

The narrator has no PERSON token in these passages. Agent 5 said it set `located: false` even where the narrator was plainly at the place. The brief says `located` is true when the passage puts its people at the place, and a narrator is one of them, so I corrected these:

| Batch | Passage | Token | Change |
|---|---|---|---|
| 06 | batch3-social-pg1587-002288 | PLACE_1 (Paris) | The diarist has "just returned from St. Germain" to Paris: `place.here` → `place.reached`, located |
| 06 | batch3-social-pg1587-002288 | PLACE_2 (St. Germain) | `place.departed`; located → true (the diarist was there before leaving) |
| 06 | batch3-social-pg1587-002322-002323 | PLACE_1 (Rome, diary header) | located → true |
| 06 | gutenqa-pg18247-the-last-man-001211 | PLACE_1 (Ravenna) | The narrator "quitted the town": `place.departed`, located → true |
| 06 | batch3-social-pg1895-003277 | PLACE_1 (All Saints' Terrace, diary header) | located → true |
| 07 | batch3-social-pg1895-003645-003646 | PLACE_1 (Naples, diarist's location) | located → true |
| 07 | batch3-settings-pg1900-000149 | PLACE_1 (Nukuheva, "the bay in which we were then lying") | located → true |
| 09 | batch3-social-pg3095-000483 | PLACE_1 (the Castle, narrator goes back there) | `place.reached`; located → true |

The other place.here blanks with `located: false` are setting descriptions with no one present, such as Egdon Heath, Botallack mine and Casterbridge. I left those as they are.

### Ship conveyance sweep

Agents 1 and 4 committed `boat` for ship scenes. Agents 2 and 3 left ships empty because "ship" is not on the list. `lists.json` gives `boat` with years "any", which I read as covering ships. For consistency, I added `boat` where the people are plainly aboard a ship:

| Batch | Passage | Change |
|---|---|---|
| 05 | P3-03-06 | conveyance `[]` → `["boat"]` (whale-ship at night) |
| 06 | gutenqa-pg159-the-island-of-doctor-moreau-000136 | conveyance `[]` → `["boat"]` |
| 08 | gutenqa-pg2360-the-riddle-of-the-sands-000295 | conveyance `[]` → `["boat"]` |
| 09 | gutenqa-pg29257-the-book-of-khalid-000109 | conveyance `[]` → `["boat"]` |

In all, I changed 16 passages, or 17 label entries, since one passage had two blanks corrected.

## For a person to decide

1. **Most place blanks are `keep` (561 of 675, 83%).**
   - **What I saw:** in the sample, most of these are correct by the brief. They are places named in passing, in dialogue, in addresses and letterheads, in lists, or seen from afar, and real geography such as the Thames, Yorkshire or Africa.
   - **Why it matters:** only 114 place blanks give the app a value to fill (here, departed or reached). If the app should swap more places, the brief's `keep` rule needs loosening. The obvious candidates are a person's home town named in dialogue, and a place where the action is told in retrospect.
2. **Narrator presence.** This decides whether first-person passages put the narrator at a place.
   - **How I applied it:** I treated the narrator as present when setting `located`, and fixed the cases listed above.
   - **What's still unclear:** the brief only speaks of people, and passages with an untokenised narrator also have empty `people` lists. Confirm that the app should treat the narrator as present.
3. **"the {{PLACE_1}} road".**
   - **The conflict:** the brief calls this `modifier`, but `check_labels.py` forces `after_the` whenever "the" stands right before a token. The agents followed the checker. Examples include "the {{PLACE_1}} Ball" and "the {{PLACE_1}} acreage development".
   - **The result:** the `form` field cannot record that these blanks are also modifiers. Consider an `after_the_modifier` form, or relaxing the checker.
4. **Months and dates as seasons.** The agents differed here.
   - **What they did:** several added a season commit for a month (April → spring, November or September → autumn, December or Christmas Eve → winter). Others left months alone, for example "APRIL 25" in batch 01 and "June 18th" in batch 05.
   - **What I left:** I left both styles in place. A month implies a season only in the northern hemisphere, and some passages are Australian.
   - **What needs deciding:** pick a rule, and the commits can be normalised mechanically.
5. **Clock times and "midnight".** `time_of_day` has no value for clock times, noon or midnight, so these are `keep`. Where the words made the matching commit certain, the agents added it.
6. **Mislabelled tokens** (the slots were not changed):
   - batch 03, `batch2-social-pg11620-000242`: PERSON_1 is really a place (Caddagat).
   - batch 08, `batch3-material-pg242-000078`: PERSON_3 ("Fuchs") is really the grandmother speaking.
   - batch 08, `batch3-material-pg25725-000737`: ORG_1 "The Crown" is a pub. It is labelled `names: place`.
   - batch 08, `P4-11-07`: PLACE_1 is a redacted town ("M——").
7. **Group names labelled `other`.** Group names such as "the Little Ones", "the Romans", "the Cossacks" and "the Dry Tree" are labelled `names: other`. Change them if the app wants groups treated as organisations.
8. **Indoors on ships.** Agent 1 left `indoors` null for ship cabins, treating a ship as a moving vehicle. Confirm that this is wanted.
