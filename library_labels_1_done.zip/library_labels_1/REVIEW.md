# Review: Library labels, part 1 (1980 passages)

## How the job was run
- **Different from PROMPT.md, on Jack's instruction:** 5 Sonnet 5.5 subagents instead of 10, each given two whole batches (twice the planned load).
  - Agent 1: batches 01 and 02.
  - Agent 2: batches 03 and 04.
  - Agent 3: batches 05 and 06.
  - Agent 4: batches 07 and 08.
  - Agent 5: batches 09 and 10.
- No batch was split.
- Each agent got BRIEF.md word for word, plus `lists.json`, its batch files, its output files and its agent number.
- All five finished, and each reported reading every passage itself. Scripts were used only to print passages and turn hand-written labels into JSON.
- No return trip was needed: when they finished, `check_labels.py` reported every batch complete with 0 errors.
- One snag: agent 5 reported that another agent overwrote its helper script in the shared scratch folder. It restored the 12 label lines it lost and moved its scripts. The checker confirms the batch is complete.

## Passages labelled (after review; `python check_labels.py`)
| Batch | Agent | Labelled | Errors | Warnings |
|---|---|---|---|---|
| 01 | 1 | 216 / 216 | 0 | 5 |
| 02 | 1 | 255 / 255 | 0 | 13 |
| 03 | 2 | 219 / 219 | 0 | 26 |
| 04 | 2 | 205 / 205 | 0 | 22 |
| 05 | 3 | 180 / 180 | 0 | 22 |
| 06 | 3 | 166 / 166 | 0 | 5 |
| 07 | 4 | 143 / 143 | 0 | 10 |
| 08 | 4 | 214 / 214 | 0 | 5 |
| 09 | 5 | 175 / 175 | 0 | 4 |
| 10 | 5 | 207 / 207 | 0 | 7 |
| **Total** | | **1980 / 1980** | **0** | **119** |

## Blank counts (after review)
**Place blanks: 865**
| fill | count | located true | located false |
|---|---|---|---|
| place.here | 52 | 51 | 1 |
| place.departed | 14 | 10 | 4 |
| place.reached | 31 | 22 | 9 |
| keep | 768 | 0 | 768 |

Keep is 89% of place blanks. I read a random 30 of the keep blanks and that is mostly right: in this part of the Library most places are only mentioned, are real places in history or digressions (Hugo, Melville, Doyle's Utah), or appear in testimony and recollection. Only 1 of the 30 (Les Misérables 011562, "the Blaru-bottom" glade) arguably should be place.here.

**Time blanks: 1326.** 1236 keep, 82 time_of_day, 8 season.

**Organisation blanks: 249**
| names | count |
|---|---|
| organisation | 132 |
| other | 74 |
| family | 40 |
| place | 3 |
| person | 0 |

Families include the Vincys, Garths, Crofts, Bigges, Oblonskys, Shepherdsons, the Jondrettes, the Cratchits, the March family and the house of Deux-Ponts. "Other" is mostly peoples, races and clans: Yahoos, Houyhnhnms, Szekelys, Gael, Saxon, Firbolg, Children of the Mist.

## Quality check
- I read 25 passages from each batch, spread evenly through the file (250 in all), against their text and slots.
- Separately, I scanned every batch for contradictory commits and read every checker warning on a likely scene-time word ("to-night", "that night", "the morning", "winter" and so on) in context.
- A clear error means a label that is plainly wrong by the brief. Arguable calls are listed further down, not counted.

| Agent | Batches | Sampled | Clear errors in sample | Rate | Extra fixes from the scans |
|---|---|---|---|---|---|
| 1 | 01, 02 | 50 | 2 (both batch 02) | 4% | 3 |
| 2 | 03, 04 | 50 | 0 | 0% | 0 |
| 3 | 05, 06 | 50 | 0 | 0% | 0 |
| 4 | 07, 08 | 50 | 1 (batch 08) | 2% | 0 |
| 5 | 09, 10 | 50 | 2 (both batch 10) | 4% | 0 |
| **All** | | **250** | **5** | **2%** | **3** |

No agent's work was wrong throughout, so no batch needed a full pass. `located` was strict everywhere: I found no case of a mentioned-only place marked located. Agents 1 and 2 were the most willing to commit a time from a kept blank. Agent 1 sometimes committed both halves of an idiom ("night and day"), which I fixed.

## Fixes made (8)
| Batch | Passage | What was wrong / what I changed |
|---|---|---|
| 10 | `gutenqa-moby-dick-or-the-whale-herman-melville-001273` | Neskyeuna/Nantucket were place.departed/place.reached and located, but the move is Gabriel's back-story, not the scene (the scene is on the Jeroboam). Changed both to keep, located false. |
| 10 | `gutenqa-peter-pan-j-m-barrie-001219` | Committed evening + summer from a kept 'summer evenings' that is habitual past ('more than once on summer evenings'). The scene itself is at night ('blanket of night'). Commits now time_of_day [night], season []. |
| 08 | `gutenqa-louise-de-la-valliere-alexandre-dumas-004440` | 'an autumn sky' / 'a spring-time scene' are about a painter's pictures in an authorial aside, not the scene's season, so they shouldn't be filled from the writer's book. Changed both TIME blanks from season/bare to keep/modifier. |
| 02 | `gutenqa-anna-karenina-leo-tolstoy-001486` | Committed all four times of day and seven weather ids because the passage summarises weeks of thaw; that makes the commits contradictory and useless as a constraint. Reduced to what holds when the passage ends: season spring, weather fine, outdoors; time_of_day empty. |
| 01 | `gutenqa-a-crystal-age-w-h-hudson-000649` | Committed morning + night from habitual 'each night ... each morning' over a period of days. Contradictory, and not the scene's own time. Cleared time_of_day. |
| 01 | `gutenqa-a-connecticut-yankee-in-king-arthur-s-court-mark-twain-000411` | Committed day + night from the idiom 'night and day'. Contradictory and not a scene time. Cleared time_of_day; the checker warning is expected. |
| 02 | `gutenqa-alice-s-adventures-in-wonderland-lewis-carroll-000194` | Committed day + night from the Pigeon's idiom 'night and day'. Cleared time_of_day; the checker warning is expected. |
| 02 | `gutenqa-a-study-in-scarlet-arthur-conan-doyle-000586` | Salt Lake City was place.departed, but Hope's departure happened three weeks before the passage, and nobody moves in it. Changed to keep (located stays false). |

## For a person to decide
1. **The 119 remaining checker warnings: "kept time words, but nothing in `commits`."**
   - BRIEF.md says such a value "must be in commits too". All five agents deliberately didn't do that where the kept time is not the scene's own time: "last night", "one night", "every evening", "all winter", "to-morrow night", testimony, recollection, plans. Most have a `note`.
   - I read the riskiest ones in context ("to-night", "that night", "the morning", "winter" and similar) and agree with the agents in every case. Committing night to a daytime scene because someone says "we shall meet to-night" would block that passage from the scenes it fits.
   - If the app really wants the hard rule, these 119 are the list to change. Three of them say "to-night": Dracula 001007 and 001305 in batch 05 (both plans made in daytime) and Dracula 001866-001867.
2. **Passages that span a change of time or season.** Room with a View 001446 commits season [autumn, summer] (summer turning to autumn). Crystal Age 000007 commits [summer, autumn] ("late summer ... autumn"). I left both. Decide whether `commits` should hold a span or only the end state. I reduced Anna Karenina 001486 to its end state because it listed every value.
3. **Arguable place fills I left alone:**
   - Jane Eyre 002110 (batch 07): Gateshead is place.departed, located. She stays a month and then leaves, so place.here is also defensible.
   - Emma 001863 (batch 05): Richmond is departed and Randalls reached by an express letter. Nobody in the scene moves.
   - Dubliners 001513 (batch 05) and Room with a View P2-04-02 (batch 02): a destination named but not reached is place.reached, located false.
   - Les Misérables 011562 (batch 08): the Blaru-bottom glade, see above.
4. **Slot surfaces that don't match the text**, flagged by the agents in `note`:
   - Anna Karenina 003757 (batch 03).
   - Crime and Punishment passage 49 and David Copperfield passage 115 (batch 04).
   - Emma 001913 (batch 05).
   - Several Gulliver and Dubliners PERSON tokens that appear only in `slots` (batch 05).
   - Batch 10: "Neverland" where "the little house" should be (passage 155), and "The morning" used as a sentence subject (185).
   - Batch 09: a "Sabbath afternoon" blank after "city of" (165).
5. **ORG `names` choices worth a glance:** peoples and races are `other`, Petit-Picpus convent is `place`, "the Lion" pub is `place`, the Ancient Kingdom of the Danes is `place`, and "Mr. Kurtz's adorers" is `other`. No organisation blank names one person.
6. **Some `feels_end` values are inferred from tone** rather than stated: agent 5 said so for batches 09 and 10, for example Dorothea "angry". I found none clearly wrong in the samples.
