# Job: label NovelWriter's Library passages (part 1 of 4)

You are the lead agent (Opus 5.5). Use **one round of exactly 10 Sonnet 5.5 subagents**, then check their work yourself. Everything needed is in this folder; you need neither the NovelWriter repository nor the internet.

## What this is for
NovelWriter is a novel-writing app. Its Library holds about 8,900 real passages from public-domain novels, with their people, places and times turned into blanks. A writer can put a passage into their own chapter, and the app fills the blanks from the writer's book. To do that well, the app must know, for every place and time blank, which value it takes and whether the people are actually **at** that place; and, for every passage, what its fixed words commit the scene to (night, rain, winter, indoors) and how its people feel by the end. The journey passages are already labelled. This job labels the rest, in four parts; this folder is part 1 (1980 passages).

Read `BRIEF.md` (the labelling rules) and `lists.json` (every allowed id) before writing the subagent prompts.

## The work split (do not shrink it)
- Agent N labels every passage in `passages/batch_NN.jsonl` (about 110 to 250 passages, roughly 23,000 words each), following `BRIEF.md`, writing `labels/batch_NN.labels.jsonl`. That is a substantial job, and that is intended: a Sonnet agent can do it well. Do not split batches further.
- Tell each to work through its file in order, append as it goes, and run `python check_labels.py NN` repeatedly until it reports no errors and every passage labelled.

Give each subagent `BRIEF.md` verbatim, plus `lists.json`, its batch file name, its output file name and its agent number.

## When they finish
1. Run `python check_labels.py` (all ten). Send back any agent with errors or missing passages (one return trip, for that only).
2. **Check quality yourself:** read 25 labelled passages from each batch against their text, spread through the file. Look hardest at `located` (people really at the place?), `fill` (place.departed and place.reached only where someone moves between places), `commits` (stated, not guessed) and `names` on organisation blanks. Read the checker's warnings too: a kept "to-night" with no night in `commits` is usually a mistake.
3. Fix clear mistakes yourself and record each fix in `REVIEW.md` (passage id, what was wrong, what you changed). If an agent's work is wrong throughout (for example, every place blank marked `located`), say so and correct that whole batch with a careful pass of your own.
4. Write `REVIEW.md`: passages labelled per batch; how many place blanks are `place.here` / `place.departed` / `place.reached` / `keep`; how many organisation blanks are a family or a person; your sampled error rate per agent; anything a person should decide.
5. Zip the folder (with `labels/` and `REVIEW.md`) as `library_labels_1_done.zip` for Jack.

## Rules
- Use only ids from `lists.json`. Never invent an id; put a suggestion in `note` instead.
- Never change a passage's text or slots.
- Report counts truthfully. If an agent failed, say which.
